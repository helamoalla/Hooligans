/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import interfaces.InterfaceCRUD;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.stage.Stage;
import model.Event;
import services.Services_event;

/**
 * FXML Controller class
 *
 * @author User
 */
public class AfficherEventController implements Initializable {
InterfaceCRUD Service_event = new Services_event();
    @FXML
    private ListView<Event> Afficher;
    @FXML
    private Button AfficherButton;
    @FXML
    private Button AjouterButton;
    @FXML
    private Button ModifierButton;
    @FXML
    private Button SupprimerButton;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void Affichet_Event(ActionEvent event) {
         ObservableList<Event> Events =FXCollections.observableArrayList(Service_event.readAll());
       Afficher.setItems(Events);
    }

    @FXML
    private void Ajouter_Event(ActionEvent event) {
          
    try {
        //bonPlanService.update(bonPlanService.readById(selectedId));
        FXMLLoader loader= new FXMLLoader(getClass().getResource("./AjouterEvent.fxml"));
        Parent view_2=loader.load();
        
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(view_2);
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(AfficherEventController.class.getName()).log(Level.SEVERE, null, ex);
    }
       
    }

    @FXML
    private void Delete_Event(ActionEvent event) {
         int selectedId= Afficher.getSelectionModel().getSelectedItem().getId_e();
        Service_event.delete(selectedId);
        Affichet_Event(event);
    }

    @FXML
    private void modifier_Event(ActionEvent event) {
    try {
        Event selectedEvent=Afficher.getSelectionModel().getSelectedItem();
        
        //bonPlanService.update(bonPlanService.readById(selectedId));
        FXMLLoader loader= new FXMLLoader(getClass().getResource("./ModifierEvent.fxml"));
        Parent view_2=loader.load();
        ModifierEventController ModifierEventController=loader.getController();
        ModifierEventController.getEvent(selectedEvent);
        ModifierEventController.e=selectedEvent;
        Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        Scene scene = new Scene(view_2);
        stage.setScene(scene);
        stage.show();
    } catch (IOException ex) {
        Logger.getLogger(AfficherEventController.class.getName()).log(Level.SEVERE, null, ex);
    }
        
        }
    }
    

