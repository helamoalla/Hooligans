/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View;

import interfaces.InterfaceCRUD;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URL;
import java.time.LocalDate;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import model.Event;
import services.Services_event;

/**
 * FXML Controller class
 *
 * @author User
 */
public class AjouterEventController implements Initializable {
InterfaceCRUD Service_event = new Services_event();
    @FXML
    private TextField nom;
    @FXML
    private TextField type;
    @FXML
    private TextField lieu;
    @FXML
    private TextField prix;
    @FXML
    private DatePicker dated;
    @FXML
    private DatePicker datef;
    @FXML
    private Button AjouterEvent;
    @FXML
    private Button importerimage;
    @FXML
    private ImageView imageview;
    @FXML
    private TextField nom_image;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void AjouterEvent(ActionEvent event) {
         if (nom.getText().length() == 0||dated.getValue().equals("")||datef.getValue().equals("")||type.getText().length() == 0||lieu.getText().length() == 0||prix.getText().length() == 0) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");
            alert.setHeaderText("Erreur de saisie !");
            alert.setContentText("Please remplir tous les champs"+ "");
            alert.show();

        } else {
             try {
                 Event e=new Event();
                 e.setNom_event(nom.getText());
                 e.setLieu_event(lieu.getText());
                 e.setType_event(type.getText());
                 
                 LocalDate d=dated.getValue();
                 
                 e.setDate_debut(java.sql.Date.valueOf(d));
                 
                 LocalDate f=datef.getValue();
                 e.setDate_fin(java.sql.Date.valueOf(f));
                 
                 e.setPrix(Double.parseDouble(prix.getText()));
          
              e.setImage(nom_image.getText());
                 Service_event.insert(e);
                 
                 FXMLLoader loader= new FXMLLoader(getClass().getResource("./AfficherEvent.fxml"));
                 Parent view_2=loader.load();
                 
                 Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
                 Scene scene = new Scene(view_2);
                 stage.setScene(scene);
                 stage.show();
             } catch (IOException ex) {
                 Logger.getLogger(AjouterEventController.class.getName()).log(Level.SEVERE, null, ex);
             }
        }
    }



     /*  */

    @FXML
    private void importerimage(ActionEvent event) throws FileNotFoundException {
        
         FileChooser fileChooser = new FileChooser();
 Stage stage=(Stage)((Node)event.getSource()).getScene().getWindow();
        
        importerimage.setOnAction(e -> {
             try {
                 FileInputStream input = null;
                 
                 File selectedFile = fileChooser.showOpenDialog(stage);
                 input = new FileInputStream(selectedFile);
                 nom_image.setText(selectedFile.getName());
                 
                 Image image = new Image(input);
                 imageview.setImage(image);
                 
             } catch (FileNotFoundException ex) {
                 Logger.getLogger(AjouterEventController.class.getName()).log(Level.SEVERE, null, ex);
             }
                 
           
                 
});
}
    
}
    
